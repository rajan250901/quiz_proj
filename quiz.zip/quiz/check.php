<h1>Result</h1>
<?php
session_start();
include("database.php");
if($_POST["submit"])
{
    if(!empty($_POST['quizcheck']))
    {
        $count=count($_POST['quizcheck']);
        echo "out of 4 you have selected ".$count." options ";
        $i=1;
        $result=0;
        $selected=$_POST['quizcheck'];
        $q="SELECT * from questions";
       $query=mysqli_query($conn,$q);
       while($rows = mysqli_fetch_array($query))
     { 
        $k=$selected[$i]%4;
        if($k==0)
        {
            $k=4;
        }
        $checked=$rows['ans_id']==$k;
        if($checked)
        {
           $result++;
        }
        $i++;
     }

     echo "<br>";
     echo "<br>";
     echo "Your score is ".$result;
    }
    $name=$_SESSION['username'];
    $email=$_SESSION['email'];
    $q="INSERT INTO marks VALUES('$name','$email','$result')";
    $query=mysqli_query($conn,$q);
}
?>