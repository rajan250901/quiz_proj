<?php 
   session_start();
   include("database.php");
   if($_POST['login'])
   {
       $count=0;
       $name=$_POST['name'];
       $email=$_POST['email'];
       $password=$_POST['password'];
       $q="SELECT * FROM student";
       $query=mysqli_query($conn,$q);
       while($rows=mysqli_fetch_array($query))
         {
       if($rows['name']==$name && $rows['email']==$email && $rows['password']==$password)
         {
          $_SESSION['username']=$name;
          $_SESSION['email']=$email;
            $count++;
            include("test.php");
         }
          }
     if($count==0)
       {
         echo "first create an account to give the test";
         include("signup.php");
       }
    }
?>