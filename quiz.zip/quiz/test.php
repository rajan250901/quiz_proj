<?php
include('database.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz</title>
    
</head>
<body>

    <h1>Welcome to Quiz World</h1>
    <h3>Select any one option out of four</h3>
    <form action="check.php" method="post">
    <?php
    for($i=1;$i<5;$i++)
    {
    $q="SELECT * from questions where qid=$i";
    $query=mysqli_query($conn,$q);
    while($rows = mysqli_fetch_array($query))
    {
         echo $rows['question'];
        echo "<br>";
        $q2="SELECT * from answers where ans_id=$i";
        $query=mysqli_query($conn,$q2);
        while($rows = mysqli_fetch_array($query))
       { ?>
         <input type="radio" name= "quizcheck[<?php echo $rows['ans_id']; ?>]" value="<?php echo $rows['aid']; ?>">
         <?php echo $rows['answers'];
         echo "<br>";
       }  
    } 
    
    }
    ?>
    <input type="submit" name="submit" value="submit">
</form>
</body>
</html>