<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        body{
            background-image: url("image.jpg");
            background-repeat: no-repeat;
            background-size: cover;
        }
        .topnav {
            
            position: fixed;
           top: 0px;
           background-color: #333;
            overflow: hidden;
}
.topnav a {
    float: right;
  color: #f2f2f2;
  text-align: center;
 padding: 14px 16px;
 text-decoration: none;
  font-size: 17px;
  
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}
h1
{
    width: 100%;
    height : 85vh;
    display: flex;
    justify-content: center;
    align-items: center;
}
h3
{
    text-align: center;
}
    </style>
</head>
<body>
    <h1>Welcome to Rajan's Page</h1>
    <h3>Login to start the test.If you are new user first register the details.</h3>
    <div class="topnav">
        <a href="signup.php">Register</a>
        <a href="login.php">Login</a>
        <a href="#Contact">Contact</a>
        <a href="#Home">Home</a>
      </div>
</body>
</html>