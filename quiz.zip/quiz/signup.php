
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in Page</title>
        <style>
            .container
            {
                margin :auto;
                padding: 200 px;
                display:block;
            }
        </style>
</head>
<body>
    <form action="password_check.php" method="post">
       <h2>Register</h2>
       <div class = "container">
       
       <tr>
       <th>Name  </th>
       <input type="text" name="name" placeholder="enter name" required>
       </tr><br><br>
       <tr>
       <th>E-mail</th>
       <input type="email" name="email" placeholder="enter email" required>
       </tr><br><br>
       <tr>
       <th>password </th>
       <input type="password" name="password1" placeholder="enter password" required>
       </tr><br><br>
       <tr>
       <th>confirm password </th>
       <input type="password" name="password2" placeholder="confirm password" required>
       </tr><br><br>
        <input type="submit" name="submit" value="submit">
       
       </div>

    </form>
</body>
</html>