     <?php 
          include("database.php");
          if($_POST['submit'])
          {
           if($_POST['password1']===$_POST['password2'])
           { 
            $name=$_POST['name'];
            $email=$_POST['email'];
            $password=$_POST['password1'];
            $q="INSERT INTO student VALUES('','$name','$email','$password')";
            $query=mysqli_query($conn,$q);
            if($query)
            {
                echo "Now Login to give the test";
                include("login.php");
            }
            else
            {
                echo "account not created";
            }
           }
          else
           {
            echo "Both Passwords Must be same.";
            echo " Please Try Again";
            include("signup.php");
           }
          }
      ?>
