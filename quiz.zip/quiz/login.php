<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in Page</title>
        <style>
            .container
            {
                margin :auto;
                padding: 200 px;
                display:block;
            }
        </style>
</head>
<body>
    <form action="datacheck.php" method="post">
       <h2>Login</h2>
       <div class = "container">
       <tr>
       <th>Name  </th>
       <input type="text" name="name" placeholder="enter name" required>
       </tr><br><br>
       <tr>
       <th>E-mail</th>
       <input type="email" name="email" placeholder="enter email" required>
       </tr><br><br>
       <tr>
       <th>password </th>
       <input type="password" name="password" placeholder="enter password" required>
       </tr><br><br>
       <tr>
       <input type="submit" name="login" value="login">
       </tr>
        </div>
    </form>
</body>
</html>